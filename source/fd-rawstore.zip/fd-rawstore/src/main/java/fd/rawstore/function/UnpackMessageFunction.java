package fd.rawstore.function;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.spark.api.java.function.PairFunction;
import org.msgpack.MessagePack;
import org.msgpack.template.Templates;
import org.msgpack.type.Value;

import fd.rawstore.bin.CanDataAnnotatedBean;
import scala.Tuple2;

public  class UnpackMessageFunction implements
  PairFunction<Tuple2<String,byte[]>,String,CanDataAnnotatedBean>{

	private static final long serialVersionUID = - 2022345678L;
	private static final MessagePack messagePack = new MessagePack();

	@Override
	public Tuple2<String,  CanDataAnnotatedBean> call(
			Tuple2<String, byte[]> t)throws Exception {
		CanDataAnnotatedBean bean = getKeyInfo(t._2);

		return new Tuple2<String,CanDataAnnotatedBean>(t._1(),bean);
	}

    protected CanDataAnnotatedBean getKeyInfo(byte[] message) throws IOException{
		Map<String, Value> unpacked =
				messagePack.read(message, Templates.tMap(Templates.TString, Templates.TValue));
		unpacked.remove("message");
		Map<String, Object> annotation = new HashMap(unpacked.size(), 1.0f);
		for(Entry<String, Value> entry:unpacked.entrySet()) {
			Object newValue;
			if(entry.getValue().isBooleanValue()) {
				newValue = entry.getValue().asBooleanValue().getBoolean();
			} else if(entry.getValue().isFloatValue()) {
				newValue = entry.getValue().asFloatValue().getFloat();
			} else if(entry.getValue().isIntegerValue()) {
				newValue = entry.getValue().asIntegerValue().longValue();
			} else {
				newValue = entry.getValue().asRawValue().getString();
			}
			annotation.put(entry.getKey(),newValue);
		}
		CanDataAnnotatedBean bean = new CanDataAnnotatedBean();
		bean.setVin((String)annotation.get("vin"));
		bean.setRecicvetime((long)annotation.get("recicvetime"));
		bean.setMessage(message);
		return bean;
	}
}
