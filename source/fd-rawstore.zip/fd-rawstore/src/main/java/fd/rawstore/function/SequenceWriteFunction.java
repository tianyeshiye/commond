package fd.rawstore.function;

import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;

import fd.rawstore.bin.CanDataAnnotatedBean;
import fd.rawstore.util.CtreateDirectory;

public class SequenceWriteFunction
implements VoidFunction<JavaPairRDD<String,CanDataAnnotatedBean>>{
	private static final long serialVersionUID = - 2022345678L;
	protected String rawStoreRootDir;
	protected String delimiter = "fffff";
	public void setRawStoreRootDir(String rawStoreRootDir) {
		this.rawStoreRootDir = rawStoreRootDir;
	}
	@Override
	public void call(JavaPairRDD<String, CanDataAnnotatedBean> rdd) {
		JavaRDD<CanDataAnnotatedBean> aa = rdd.values();

		write(aa);
	}

	protected  void write(JavaRDD<CanDataAnnotatedBean> rdd) {
		if(!rdd.isEmpty()) {
			ZonedDateTime now = ZonedDateTime.now();
			final String path =
					new Path(this.rawStoreRootDir,CtreateDirectory.createDirectoryPathFromTime(now))
					.toString();
			Configuration conf = new Configuration();
			conf.set("mapreduce.outpu.basename", String.valueOf(System.currentTimeMillis()));
			conf.set("mapreduce.output.fileoutputformat.compress", "true");
			conf.set("mapred.map.output.compress.codec", "org.apache.hadoop.io.compress.SnappyCodec");
			conf.set("mapred.map.output.compress.type", "BLOCK");
			

			conf.set("fs.swift.service.SparkTest.auth.url", "http://127.0.0.1:5000/v2.0/tokens");
			conf.set("fs.swift.service.SparkTest.auth.endpoint.prefix", "endpoints");
			conf.set("fs.swift.service.SparkTest.http.port", "8080");
			conf.set("fs.swift.service.SparkTest.region", "RegionOne");
			conf.set("fs.swift.service.SparkTest.public", "true");
			conf.set("fs.swift.service.SparkTest.tenant", "demo");
			conf.set("fs.swift.service.SparkTest.username", "demo");
			conf.set("fs.swift.service.SparkTest.password", "abcd1234");

			
			rdd.mapToPair(new TranstormToSequenceFileFormat(this.delimiter.getBytes(StandardCharsets.UTF_8)))
			.saveAsNewAPIHadoopFile("swift://container.SparkTest/path", NullWritable.class, BytesWritable.class,
					SequenceFileOutputFormat.class,conf);


		}
	}
}
