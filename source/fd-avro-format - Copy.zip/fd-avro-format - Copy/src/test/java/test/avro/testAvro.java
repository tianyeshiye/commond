package test.avro;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.avro.AvroGenericRecordWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapreduce.Mapper.Context;

import jp.co.fd.inputformat.CustomAvroContainerInputFormat;

public class testAvro {

    public static class MyMapper extends MapReduceBase
            implements Mapper<NullWritable, AvroGenericRecordWritable, NullWritable, Text> {

        @Override
        public void map(NullWritable key, AvroGenericRecordWritable value, OutputCollector<NullWritable, Text> output,
                Reporter reporter) throws IOException {

            System.out.println("key:\t " + key);

            System.out.println("value:\t " + value);

            output.collect(key, new Text(value.getRecord().toString()));

            System.out.println("-------------------------");
        }
    }

    public static void main(String[] args) throws Exception {

        JobConf conf = new JobConf(testAvro.class);
        conf.setJobName("temp");

        Path outPath = new Path("output/output" + String.valueOf(System.currentTimeMillis()));

        FileSystem.get(conf).delete(outPath, true);

        conf.setInputFormat(CustomAvroContainerInputFormat.class);
        conf.setJarByClass(testAvro.class);

        conf.setMapperClass(MyMapper.class);
        conf.setNumReduceTasks(0);

        conf.setMapOutputKeyClass(NullWritable.class);
        conf.setMapOutputValueClass(Text.class);

        // conf.setOutputFormat(TextOutputFormat.class);

        FileInputFormat.setInputPaths(conf, new Path("input/avro"));
        FileOutputFormat.setOutputPath(conf, new Path("output/output" + String.valueOf(System.currentTimeMillis())));

        JobClient.runJob(conf);

    }
}
