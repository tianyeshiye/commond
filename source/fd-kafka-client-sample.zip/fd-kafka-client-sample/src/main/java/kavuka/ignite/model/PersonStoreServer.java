package kavuka.ignite.model;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;

/**
 * Created by Future Data on 2018-06-18.
 */
public class PersonStoreServer {
    public static void main(String[] args) throws IgniteException {
        Ignite ignite = Ignition.start("config/spring-ignite.xml");
    }
}