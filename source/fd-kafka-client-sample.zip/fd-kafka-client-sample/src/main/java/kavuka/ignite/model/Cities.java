package kavuka.ignite.model;

import java.io.Serializable;

import org.apache.ignite.cache.query.annotations.QuerySqlField;


/**
 * cities
 * Created by Future Link on 2018-06-18.
 */
public class Cities implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	 @QuerySqlField
	private Long id;
	 @QuerySqlField
	private String name;
	 /**
	 * @return id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id セットする id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}
	 public Cities() {

	    }

	 public Cities(Long id, String name) {
	        this.id = id;
	        this.name = name;
	    }


}
