package kavuka.ignite.model;

import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;

/**
 *
 * Created by Future Data on 2018-06-18.
 */
public class PersonStoreClient {
    public static void main(String[] args) throws IgniteException {
        Ignition.setClientMode(true);
        Ignite ignite = Ignition.start("config/spring-ignite.xml");

        IgniteCache<Long, Person> cache = ignite.getOrCreateCache("personCache");
        cache.loadCache(null);
        QueryCursor<List<?>> cursor = cache.query(new SqlFieldsQuery("select id, orgId,name from Person"));
        System.out.println(cursor.getAll());
        Person p=new Person(44,5,"31 140");
        cache.put(p.getId(),p);

        ignite.close();
    }

    public static void toCachePostGis(Ignite ignite,Integer key,String lonlat) throws Exception {

        IgniteCache<Long, Person> cache = ignite.getOrCreateCache("personCache");
        cache.loadCache(null);
        QueryCursor<List<?>> cursor = cache.query(new SqlFieldsQuery("select id, orgId,name from Person"));
//        System.out.println(cursor.getAll());
        Person p=new Person(key,key,lonlat);
        cache.put(p.getId(),p);

    }

    public static Ignite getIgnite() {

        Ignite ignite = Ignition.start("config/spring-ignite.xml");
        return ignite;
    }

}