package fd.fd_kafka_client_sample;

public class ConsumerDriver2 {
	public static void main(String[] args) {
		Consumer consumer = new Consumer("my-topic");
		consumer.start();

	}
}