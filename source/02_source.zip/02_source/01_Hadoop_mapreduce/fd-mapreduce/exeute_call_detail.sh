#!/bin/sh

JAVA_OPTS=

JAVA_OPTS="${JAVA_OPTS} -Dsbtm.propertyFile=/hdfs/etc/sbtm.properties"
HADOOP_OPTS="${JAVA_OPTS}"


HADOOP_OPTS="${HADOOP_OPTS} -Xms1024M"
HADOOP_OPTS="${HADOOP_OPTS} -Xmx1024M"
export HADOOP_OPTS



hadoop jar HadoopMapReduce.jar jp.co.fd.mapreduce.calldetail.CallDetailControl 00 12345
RESULT=$?

exit ${RESULT}

