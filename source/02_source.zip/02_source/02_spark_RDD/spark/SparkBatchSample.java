package tianye.sample.spark;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import function2.CanUnitBean;
import function2.TelegramHash;
import function2.Unit;
import scala.Tuple2;

public class SparkBatchSample {

    public static void main(String[] args) {

        SparkBatchSample sample = new SparkBatchSample();
        sample.startBatch();
    }

    // Map<mainId, List<subId>>
    private Map<Short, List<Short>> canIdRelation = new HashMap<Short, List<Short>>();
    {
        List<Short> subIdList = new ArrayList<Short>(Arrays.asList((short) 0x01, (short) 0x22, (short) 0x122));
        canIdRelation.put((short) 0x201, subIdList);
    }

    private void startBatch() {

        SparkConf conf = new SparkConf().setAppName("CanTimeReducer").setMaster("local[2]");

        JavaSparkContext sc = new JavaSparkContext(conf);

        GenerateDataUtils dataUtils = new GenerateDataUtils();

        JavaPairRDD<TelegramHash, CanUnitBean> originalRDD = dataUtils.getRDD(sc);

        // repartition
        // JavaPairRDD<TelegramHash, CanUnitBean> repartitionRDD =
        // originalRDD.repartition(numPartitions)

        // sort
        // repartitionRDD.

        // logical deal
        // dealedRDD =
    }

}
